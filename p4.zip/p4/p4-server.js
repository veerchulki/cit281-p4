// Import required modules
const express = require('express');
const { getQuestions, getAnswers, getQuestionsAnswers, getQuestion, getAnswer, getQuestionAnswer } = require('./p4-module.js');

const app = express();
const port = 3000;

// Middleware to handle JSON responses
app.use(express.json());

// Route: /cit/question
app.get('/cit/question', (req, res) => {
  const questions = getQuestions();
  res.json({
    error: '',
    statusCode: 200,
    questions: questions
  });
});

// Route: /cit/answer
app.get('/cit/answer', (req, res) => {
  const answers = getAnswers();
  res.json({
    error: '',
    statusCode: 200,
    answers: answers
  });
});

// Route: /cit/questionanswer
app.get('/cit/questionanswer', (req, res) => {
  const questionsAnswers = getQuestionsAnswers();
  res.json({
    error: '',
    statusCode: 200,
    questions_answers: questionsAnswers.map(item => ({
      question: item.question,
      answer: item.answer
    }))
  });
});

// Route: /cit/question/:number
app.get('/cit/question/:number', (req, res) => {
  const { number } = req.params;
  const result = getQuestion(number);
  if (result.error) {
    res.status(400).json(result);
  } else {
    res.json({
      error: result.error,
      statusCode: 200,
      question: result.question,
      number: result.number
    });
  }
});

// Route: /cit/answer/:number
app.get('/cit/answer/:number', (req, res) => {
  const { number } = req.params;
  const result = getAnswer(number);
  if (result.error) {
    res.status(400).json(result);
  } else {
    res.json({
      error: result.error,
      statusCode: 200,
      answer: result.answer,
      number: result.number
    });
  }
});

// Route: /cit/questionanswer/:number
app.get('/cit/questionanswer/:number', (req, res) => {
  const { number } = req.params;
  const result = getQuestionAnswer(number);
  if (result.error) {
    res.status(400).json(result);
  } else {
    res.json({
      error: result.error,
      statusCode: 200,
      question: result.question,
      answer: result.answer,
      number: result.number
    });
  }
});

// Route: * (Catch-all for unmatched routes)
app.get('*', (req, res) => {
  res.status(404).json({
    error: 'Route not found',
    statusCode: 404
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
